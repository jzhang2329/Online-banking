package com.jz.finance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetBankingCoreServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
