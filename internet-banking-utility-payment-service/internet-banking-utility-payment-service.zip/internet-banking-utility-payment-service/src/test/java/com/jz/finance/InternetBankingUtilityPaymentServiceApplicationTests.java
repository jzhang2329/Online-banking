package com.jz.finance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetBankingUtilityPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
