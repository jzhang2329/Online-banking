package com.jz.finance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternetBankingUtilityPaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternetBankingUtilityPaymentServiceApplication.class, args);
	}

}
