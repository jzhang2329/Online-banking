package com.jz.finance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetBankingApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
